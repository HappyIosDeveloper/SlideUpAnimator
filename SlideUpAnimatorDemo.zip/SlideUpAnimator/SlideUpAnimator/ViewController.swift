//
//  ViewController.swift
//  SlideUpAnimator
//
//  Created by Alfredo Uzumaki on 6/11/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        view.slideUpViews(delay: 0.1)
    }
}

// Also you can use this guys:

//        view.slideUpViewsQuickly(delay: 0.1) // for faster animation
//        view.slideUpViewsQuickly(delay: 0.1, comple: nil) // if you want to know when animation is finished
//        view.slideLeftViews(delay: 0.1) // if you want slide in views from right
//        view.hideOutView() // if you want to hide out some views
//        view.hideAllSubViews() // if you want to hide views in 'ViewDidLoad' then appear them later...

//  notice: 'view' that used in above exmaples could be you pranet view of objects you want to animate them.
